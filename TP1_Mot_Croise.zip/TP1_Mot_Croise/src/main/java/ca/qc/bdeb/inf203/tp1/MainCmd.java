package ca.qc.bdeb.inf203.tp1;

public class MainCmd {

    public static void main(String[] args) {
        String nom = "mots-croises1.txt";
        MotCroisse test = new MotCroisse(nom);
    }
}
