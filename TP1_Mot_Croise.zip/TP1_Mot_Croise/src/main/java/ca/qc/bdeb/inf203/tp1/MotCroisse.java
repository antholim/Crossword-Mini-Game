package ca.qc.bdeb.inf203.tp1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class MotCroisse {
    private boolean partieFinie;
    private boolean fichierErrone = false;
    private int maxHorizontal = 0;
    private int maxVertical = 0;
    private String nomDuFichier;
    private String grille[][];
    private ArrayList<String> listeDesMots = new ArrayList<>();
    private ArrayList<Integer> coordonneesX = new ArrayList<>();

    private ArrayList<Integer> coordonneesY = new ArrayList<>();
    private ArrayList<String> directionDuMot = new ArrayList<>();

    private ArrayList<String> definitionsDesMots = new ArrayList<>();
    private BufferedReader lireFichier;


    public MotCroisse(String nomDuFichier) {
        this.nomDuFichier = nomDuFichier;
        this.partieFinie = partieFinie;
        txtVersArrays();
        tailleDeLaGrille();
        remplirLaGrille();
        testgrille();
    }

    public void txtVersArrays() {
        try {
            lireFichier = new BufferedReader(new FileReader(nomDuFichier));
            //Skip Lignes (A modifier)
            lireFichier.readLine();
            lireFichier.readLine();
//            while (lireFichier.read() == '#') {
//                char string[] = lireFichier.readLine().toCharArray();
//            }
            String ligne;

            while ((ligne = lireFichier.readLine()) != null) {
                String tab[] = ligne.split(":");
                for (int i = 0; i < tab.length; i++) {
                    switch (i) {
                        case 0 -> {
                            listeDesMots.add(tab[i]);
                        }
                        case 1 -> {
                            coordonneesX.add(Integer.parseInt(tab[i]));
                        }
                        case 2 -> {
                            coordonneesY.add(Integer.parseInt(tab[i]));
                        }
                        case 3 -> {
                            directionDuMot.add(tab[i]);
                        }
                        case 4 -> {
                            definitionsDesMots.add(tab[i]);
                        }
                    }
                }
            }
//            Test
//            System.out.println(listeDesMots.toString());
//            System.out.println(coordonneesX.toString());
//            System.out.println(coordonneesY.toString());
//            System.out.println(directionDuMot.toString());
//            System.out.println(definitionsDesMots.toString());

        } catch (FileNotFoundException e) {
            System.out.println("Fichier non trouvé");
        } catch (IOException e) {

        }
    }
    public boolean estComplet() {
        if (partieFinie) {
            return true;
        }
        return partieFinie;
    }
    public void tailleDeLaGrille() {
        for (int i = 0; i < directionDuMot.size(); i++) {
            if (directionDuMot.get(i).equals("H") && maxHorizontal < coordonneesX.get(i) + listeDesMots.get(i).length()) {
                maxHorizontal = coordonneesX.get(i) + listeDesMots.get(i).length();
            } else if (directionDuMot.get(i).equals("V") && maxHorizontal < coordonneesY.get(i) + listeDesMots.get(i).length()) {
                maxVertical = coordonneesY.get(i) + listeDesMots.get(i).length();
            }
        }
        System.out.println(maxHorizontal);
        System.out.println(maxVertical);
//        grille = new String[maxHorizontal][maxVertical];
        grille = new String[maxVertical][maxHorizontal];
        System.out.println(coordonneesX.toString());
    }
    public void remplirLaGrille() {
        for (int i = 0; i < listeDesMots.size(); i++) {
            char charDesMots[] = listeDesMots.get(i).toCharArray();
            if (directionDuMot.get(i).equals("H")) {
                for (int j = 0; j < charDesMots.length; j++) {
//                    System.out.println(coordonneesX.get(i));
//                    grille[coordonneesX.get(i)][coordonneesY.get(i)] = String.valueOf(charDesMots[j]);
                    System.out.println(String.valueOf(charDesMots[j]));
                    grille[coordonneesY.get(i)][coordonneesX.get(i) + j] = String.valueOf(charDesMots[j]);
                }
            } else if (directionDuMot.get(i).equals("V")) {
                for (int j = 0; j < charDesMots.length; j++) {
                    grille[coordonneesY.get(i) + j][coordonneesX.get(i)] = String.valueOf(charDesMots[j]);
                }
            }
        }
    }
    public void testgrille() {
        for (int i = 0; i < grille.length; i++) {
            for (int j = 0; j < grille[i].length; j++) {
                if (grille[i][j] == null) {
                    grille[i][j] = "*";
                }
                System.out.print(grille[i][j]);
            }
            System.out.println();
        }
    }
}
